Place here your .rom files generated
with the mra tool as described in

https://github.com/jotego/jtbin/wiki/Analogue-Pocket-Cores
